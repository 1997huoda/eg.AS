package cn.jiguang.imui.conversations;


import android.content.Context;
import android.util.AttributeSet;

import cn.jiguang.imui.commons.Style;

public class ConversationStyle extends Style {

    protected ConversationStyle(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
