package com.example.huoda.left_ship;

/**
 * @author Admin
 * @version $Rev$
 * @des ${TODO}
 * @updateAuthor $Author$
 * @updateDes ${TODO}
 */
class PermissonItem {
    public PermissonItem(String accessFineLocation, String 定位, int permission_ic_location) {
    }
}
