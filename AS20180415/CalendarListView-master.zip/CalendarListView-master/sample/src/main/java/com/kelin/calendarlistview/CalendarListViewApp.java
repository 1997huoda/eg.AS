package com.kelin.calendarlistview;

import android.app.Application;

/**
 * Created by kelin on 16-4-12.
 */
public class CalendarListViewApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
