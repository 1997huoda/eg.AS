package com.github.tibolte.agendacalendarview.models;

import java.util.Date;
import java.util.List;

/**
 * Week model class.
 */
public class WeekItem implements IWeekItem {
    private int mWeekInYear;
    private int mYear;
    private int mMonth;
    private Date mDate;
    private String mLabel;
    private List<IDayItem> mDayItems;

    // region Constructor

    public WeekItem(int weekInYear, int year, Date date, String label, int month) {
        this.mWeekInYear = weekInYear;
        this.mYear = year;
        this.mDate = date;
        this.mLabel = label;
        this.mMonth = month;
    }
    public WeekItem(WeekItem original) {
        this.mWeekInYear = original.getWeekInYear();
        this.mYear = original.getYear();
        this.mMonth = original.getMonth();
        this.mDate = original.getDate();
        this.mLabel = original.getLabel();
        this.mDayItems = original.getDayItems();
    }

    public WeekItem(){

    }

    // endregion

    // region Getters/Setters

    public int getWeekInYear() {
        return mWeekInYear;
    }

    public void setWeekInYear(int weekInYear) {
        this.mWeekInYear = weekInYear;
    }

    public int getYear() {
        return mYear;
    }

    public void setYear(int year) {
        this.mYear = year;
    }

    public int getMonth() {
        return mMonth;
    }

    public void setMonth(int month) {
        this.mMonth = month;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        this.mDate = date;
    }

    public String getLabel() {
        return mLabel;
    }

    public void setLabel(String label) {
        this.mLabel = label;
    }

    public List<IDayItem> getDayItems() {
        return mDayItems;
    }

    public void setDayItems(List<IDayItem> dayItems) {
        this.mDayItems = dayItems;
    }

    @Override
    public IWeekItem copy() {
        return new WeekItem(this);
    }

    // endregion

    @Override
    public String toString() {
        return "WeekItem{"
                + "label='"
                + mLabel
                + '\''
                + ", weekInYear="
                + mWeekInYear
                + ", year="
                + mYear
                + '}';
    }
}
