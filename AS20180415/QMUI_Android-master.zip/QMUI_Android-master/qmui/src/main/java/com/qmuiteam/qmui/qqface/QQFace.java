package com.qmuiteam.qmui.qqface;

/**
 * @author cginechen
 * @date 2016-12-21
 */

public class QQFace {
    private String name;
    private int res;

    public QQFace(String name, int res) {
        this.name = name;
        this.res = res;
    }

    public String getName() {
        return name;
    }

    public int getRes() {
        return res;
    }
}
