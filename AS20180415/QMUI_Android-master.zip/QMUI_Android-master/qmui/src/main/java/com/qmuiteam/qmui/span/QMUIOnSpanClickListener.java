package com.qmuiteam.qmui.span;

/**
 * @author cginechen
 * @date 2017-03-20
 */

public interface QMUIOnSpanClickListener {
    boolean onSpanClick(String text);
}
