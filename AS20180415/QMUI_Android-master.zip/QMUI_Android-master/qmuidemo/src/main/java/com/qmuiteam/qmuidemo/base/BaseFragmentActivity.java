package com.qmuiteam.qmuidemo.base;

import com.qmuiteam.qmui.arch.QMUIFragmentActivity;

/**
 * Created by cgspine on 2018/1/7.
 */

public abstract class BaseFragmentActivity extends QMUIFragmentActivity {
}
