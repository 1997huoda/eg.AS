package com.qmuiteam.qmuidemo.lib;

/**
 * @author cginechen
 * @date 2016-12-14
 */

public enum Group {
    Component,
    Helper,
    Lab,
    Other
}
