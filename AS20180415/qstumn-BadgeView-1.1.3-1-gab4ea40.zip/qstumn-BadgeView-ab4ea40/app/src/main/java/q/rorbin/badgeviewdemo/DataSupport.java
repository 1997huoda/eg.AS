package q.rorbin.badgeviewdemo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chqiu on 2017/2/13.
 */

public class DataSupport {
    private List<String> mDatas;

    public DataSupport() {
        mDatas = new ArrayList<>();
        mDatas.add("(`･ω･´)ฅ铲屎官快来");
        mDatas.add("ฅ(´-ω-`)ฅ好酥胡");
        mDatas.add("~(=^･ω･^)ฅ☆ 澡桑嚎啊小婊贝");
        mDatas.add("(=ฅರ﹏ರ)ฅ我要小鱼干");
        mDatas.add("(ฅ‵皿′)ฅ︵┻┻ 为什么不跟我玩儿");
        mDatas.add("ヽ(ฅ≧へ≦)ฅ饭不好吃");
        mDatas.add("(╬￣皿￣)ฅ拒绝洗澡");
        mDatas.add("ฅ(=￣.￣||)ฅ愚蠢的人类");
        mDatas.add("☆*:.｡. ฅ(≧▽≦)ฅ .｡.:*☆ ");
        mDatas.add("ヾ((๑˘ㅂ˘๑)ฅ^._.^ฅ我萌吗");
        mDatas.add("༻ི(ؔᵒ̶̷ᵕؔᵒ̷̶)༄୭*ˈ 浪到飞起");
        mDatas.add("*:ஐ٩(๑´ᵕ`)۶ஐ:* 透心凉心飞扬");
        mDatas.add("˚₊*୧⃛(๑⃙⃘⁼̴̀꒳⁼̴́๑⃙⃘)୨⃛*₊˚⋆ 精神百倍");
        mDatas.add("٩(ꇐ‿ꇐ)۶世界那么大我想去看看");
        mDatas.add("๛꜀꒰ ˟⌂˟꜀ ꜆꒱꜆ 起来，不愿做作业的人们");
        mDatas.add("˚‧·(´ฅ･ｪ･ฅ‘)‧º.喵，救命啊，人家怕水");
        mDatas.add("(＾,,ԾｪԾ,,＾)这款裙子是为本宝宝定制的吗");
        mDatas.add("ლ(ಠｪಠ)و美图软件用的好，老公才好找");
        mDatas.add("(҂`･ｪ･´) <,︻╦̵̵̿╤─ ҉ - -- 让你秀恩爱！");
        mDatas.add("为你加油！！！！！！\n" +
                "　☆  *　.  　☆\n" +
                "　　. ∧＿∧　∩　* ☆\n" +
                "*  ☆ ( ・∀・)/ .\n" +
                "　.  ⊂　　 ノ* ☆\n" +
                "☆ * (つ ノ  .☆\n" +
                "　　 (ノ");
        mDatas.add("老\n" +
                "　板\n" +
                "　　说\n" +
                "　　　今\n" +
                "　　　　天\n" +
                "　　　　　放\n" +
                "　　　　　 假\n" +
                "　　　     ！\n" +
                "　ヽ＼　 /／\n" +
                "　 　 ∧∧　｡\n" +
                "　 ﾟ (ﾟ∀ﾟ)っ ﾟ\n" +
                "　　　(っﾉ\n" +
                "　 　　`Ｊ");
        mDatas.add("巴拉巴拉巴拉，把你变成猪！\n" +
                "　 ∧＿∧\n" +
                " （｡･ω･｡)つ━☆・*。\n" +
                "  ⊂　　 ノ 　　　・゜+.\n" +
                "　しーＪ　　　°。+ *´¨)\n" +
                "　　　       　　.· ´¸.·*´¨) ¸.·*¨)\n" +
                "　　　　　　　     　(¸.·´ (¸.·’*");
    }

    public List<String> getData() {
        return mDatas;
    }
}
