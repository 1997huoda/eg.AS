package com.werb.mycalendardemo.utils;

/**
 * 记录服务器地址信息
 * Created by acer-pc on 2016/3/4.
 */
public class GlobalContants {

    public static final String SERVER_URL="http://10.1.1.237/calendar/";
}
