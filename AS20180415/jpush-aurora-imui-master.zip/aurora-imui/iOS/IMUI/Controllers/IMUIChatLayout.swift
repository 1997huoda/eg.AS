//
//  IMUIChatLayout.swift
//  IMUIChat
//
//  Created by oshumini on 2017/2/27.
//  Copyright © 2017年 HXHG. All rights reserved.
//

import UIKit

class IMUIChatLayout: NSObject {

}
