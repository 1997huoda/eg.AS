//
//  CIImageView.swift
//  IMUIChat
//
//  Created by oshumini on 2017/4/12.
//  Copyright © 2017年 HXHG. All rights reserved.
//

import Foundation
