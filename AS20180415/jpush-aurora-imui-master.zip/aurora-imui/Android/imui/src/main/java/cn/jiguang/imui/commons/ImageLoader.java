package cn.jiguang.imui.commons;


import android.widget.ImageView;

public interface ImageLoader {
    void loadImage(ImageView imageView, String url);
}
