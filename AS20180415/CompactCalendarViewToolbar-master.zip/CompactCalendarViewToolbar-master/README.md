# CompactCalendarViewToolbar
Using the library [CompactCalendarView](https://github.com/SundeepK/CompactCalendarView) in Android Toolbar.

![Demo](https://github.com/kleisauke/CompactCalendarViewToolbar/blob/master/images/compact-calendar-toolbar-demo.gif)
