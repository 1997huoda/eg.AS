﻿//------------------------------------------------------------------------------
// <copyright company="Tunynet">
//     Copyright (c) Tunynet Inc.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

using RestSharp;
using System.Web;
using System.Web.Helpers;
using Tunynet.Common;
using Tunynet.Utilities;

namespace Tunynet.Spacebuilder
{
    /// <summary>
    /// 新浪微博帐号获取器
    /// </summary>
    public class SinaWeiboAccountGetter : ThirdAccountGetter
    {
        private RestClient _restClient;

        /// <summary>
        /// 构造函数
        /// </summary>
        public SinaWeiboAccountGetter()
        {
            _restClient = new RestClient("https://api.weibo.com");
        }

        /// <summary>
        /// 名称
        /// </summary>
        public override string AccountTypeName
        {
            get { return "新浪微博"; }
        }

        /// <summary>
        /// 官方网站地址
        /// </summary>
        public override string AccountTypeUrl
        {
            get { return "http://www.weibo.com/"; }
        }

        /// <summary>
        /// 帐号类型Key
        /// </summary>
        public override string AccountTypeKey
        {
            get { return AccountTypeKeys.Instance().SinaWeibo(); }
        }

        /// <summary>
        /// 获取第三方网站空间主页地址
        /// </summary>
        /// <param name="identification"></param>
        /// <returns></returns>
        public override string GetSpaceHomeUrl(string identification)
        {
            return string.Format("http://weibo.com/u/{0}", identification);
        }

        /// <summary>
        /// 获取身份认证Url
        /// </summary>
        /// <returns></returns>
        public override string GetAuthorizationUrl()
        {
            string getAuthorizationCodeUrlPattern = "https://api.weibo.com/oauth2/authorize?response_type=code&client_id={0}&redirect_uri={1}";
            return string.Format(getAuthorizationCodeUrlPattern, AccountType.AppKey, WebUtility.UrlEncode(CallbackUrl));
        }

        /// <summary>
        /// 获取身份认证Url(自定义返回页面)
        /// </summary>
        /// <returns></returns>
        public override string GetAuthorizationUrl(string url)
        {
            string getAuthorizationCodeUrlPattern = "https://api.weibo.com/oauth2/authorize?response_type=code&client_id={0}&redirect_uri={1}";
            return string.Format(getAuthorizationCodeUrlPattern, AccountType.AppKey, WebUtility.UrlEncode(url));
        }

        /// <summary>
        /// 获取当前第三方帐号上的访问授权
        /// </summary>
        /// <param name="Request"></param>
        /// <param name="expires_in">有效期（单位：秒）</param>
        /// <returns></returns>
        public override string GetAccessToken(HttpRequestBase Request, out int expires_in)
        {
            //通过Authorization Code获取Access Token
            _restClient.Authenticator = null;
            string code = Request.QueryString.GetString("code", string.Empty);
            var request = new RestRequest(Method.POST);
            request.Resource = "oauth2/access_token?grant_type=authorization_code&client_id={appkey}&client_secret={appsecret}&code={code}&redirect_uri={callbackurl}";
            request.AddParameter("appkey", AccountType.AppKey, ParameterType.UrlSegment);
            request.AddParameter("appsecret", AccountType.AppSecret, ParameterType.UrlSegment);
            request.AddParameter("code", code, ParameterType.UrlSegment);
            request.AddParameter("callbackurl", CallbackUrl, ParameterType.UrlSegment);
            var response = Execute(_restClient, request);
            dynamic json = Json.Decode(response.Content);
            expires_in = json.expires_in;
            return json.access_token;
        }

        /// <summary>
        /// 获取当前第三方帐号上的用户
        /// </summary>
        /// <param name="accessToken">访问授权</param>
        /// <param name="identification">身份标识</param>
        /// <returns></returns>
        public override ThirdUser GetThirdUser(string accessToken, string identification)
        {
            //Step1：通根据access_token获得对应用户身份的openid
            _restClient.Authenticator = new CommonOAuthAuthenticator(accessToken);
            var request = new RestRequest(Method.GET);
            request.RequestFormat = DataFormat.Json;
            if (string.IsNullOrEmpty(identification))
            {
                request.Resource = "2/account/get_uid.json";
                var response = Execute(_restClient, request);
                identification = GetParmFromContent(response.Content, @"""uid"":(?<uid>[^}]+)", "uid");
                if (string.IsNullOrEmpty(identification))
                    return null;
            }
            //Step2：调用OpenAPI，获取用户信息
            request = new RestRequest(Method.GET);
            request.RequestFormat = DataFormat.Json;
            //request.AddHeader("Content-Type", "application/json");
            request.Resource = "2/users/show.json";
            request.AddParameter("uid", identification);
            var getUserInfoResponse = Execute(_restClient, request);
            var weiboUser = Json.Decode(getUserInfoResponse.Content);
            GenderType gender = GenderType.NotSet;
            if (weiboUser.gender == "m")
            {
                gender = GenderType.Male;
            }
            else if (weiboUser.gender == "f")
            {
                gender = GenderType.FeMale;
            }
            else
                gender = GenderType.NotSet;
            return new ThirdUser
            {
                AccountTypeKey = AccountType.AccountTypeKey,
                Identification = identification,
                AccessToken = accessToken,
                NickName = weiboUser.screen_name,
                Gender = gender,
                UserAvatarUrl = weiboUser.avatar_large
            };
        }
    }
}