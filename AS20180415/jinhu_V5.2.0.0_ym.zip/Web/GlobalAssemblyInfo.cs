﻿using System.Reflection;
using System.Resources;

[assembly: AssemblyProduct("Spacebuilder")]
[assembly: AssemblyCompany("青岛拓宇网络科技有限公司")]
[assembly: AssemblyCopyright("© Tunynet Inc. All Rights Reserved.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("zh-CN")]

// 指定程序集（DLL文件）的文件版本号，版本信息由下面四个值组成:
//
//      主版本
//      次版本
//      内部版本号
//      修订号
//
// 可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
// 方法是按如下所示使用“*”:
[assembly: AssemblyVersion("5.2.0.0")]

// 指定程序集（DLL文件）的的产品版本号，为NuGet打包指定Semantic Versioning。例如：1.0.0-beta
// 参考http://docs.nuget.org/docs/reference/versioning
[assembly: AssemblyInformationalVersion("5.2.0")]

// 允许部分受信任的调用方访问程序集
//[assembly: AllowPartiallyTrustedCallers]