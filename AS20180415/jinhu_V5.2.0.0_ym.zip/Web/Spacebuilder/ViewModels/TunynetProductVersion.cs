﻿////------------------------------------------------------------------------------
// <copyright company="Tunynet">
//     Copyright (c) Tunynet Inc.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//namespace Tunynet.Spacebuilder
//{
//    /// <summary>
//    /// 最新版本的数据信息
//    /// </summary>
//    public class TunynetProductVersion
//    {
//        /// <summary>
//        /// 最新版本
//        /// </summary>
//        public string MostRecentVersion { get; set; }
//        /// <summary>
//        /// 最新版本信息
//        /// </summary>
//        public string MostRecentVersionInfo { get; set; }
//        /// <summary>
//        /// 最新版本历史Url
//        /// </summary>
//        public string MostRecentVersionHistoryUrl { get; set; }
//    }
//}